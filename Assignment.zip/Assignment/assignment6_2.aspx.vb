﻿Imports System.Data.SqlClient
Partial Class assignment6_2
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\malik\Documents\tmp.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        Dim cmd As New SqlCommand
        Dim check As Boolean
        Dim gender As String
        If rdomale.Checked = True Then
            gender = "Male"
        Else
            gender = "Female"
        End If
        cmd.CommandText = "insert into std(name,age,gender,semester,email) values('" & txtname.Text & "'," & Val(txtage.Text) & ",'" & gender & "','" & DropDownList1.SelectedValue & "','" & txtemail.Text & "')"
        cmd.Connection = cn
        check = cmd.ExecuteNonQuery()
        If check Then
            pnlAlert.Visible = True
        Else
            pnlAlert.Visible = False
        End If
        txtname.Text = ""
        txtage.Text = ""
        txtemail.Text = ""
        rdomale.Checked = False
        DropDownList1.ClearSelection()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        cn.Open()
        pnlAlert.Visible = False
    End Sub
End Class
