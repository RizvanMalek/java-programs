﻿
Partial Class assignment3
    Inherits System.Web.UI.Page

    Protected Sub btnsubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnsubmit.Click
        Panel1.Visible = True
    End Sub
End Class
