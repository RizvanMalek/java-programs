﻿Imports System.IO
Partial Class assignment1
    Inherits System.Web.UI.Page



    Protected Sub btn2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn2.Click
        Dim concate As String
        For Each lstitm As ListItem In chklstHobby.Items
            If lstitm.Selected = True Then
                concate = concate + lstitm.Text
                concate = concate + vbNewLine
            End If
        Next
        txtoutput2.Text = concate
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = rdolist.SelectedValue
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox2.Text = DropDownList1.SelectedValue
    End Sub

    Protected Sub btnlink_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnlink.Click
        Response.Redirect("index.aspx")
    End Sub

    Protected Sub btnnew_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnnew.Click
        Dim concate As String
        Dim i As Integer
        'concate = ""
        For i = 0 To lstItems.Items.Count() - 1
            If lstItems.Items.Item(i).Selected = True Then
                concate = concate + lstItems.Items.Item(i).Text
                concate = concate + vbNewLine
            End If
        Next
        txtoutput.Text = concate
    End Sub
End Class
