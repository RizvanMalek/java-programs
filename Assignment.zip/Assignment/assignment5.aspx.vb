﻿
Partial Class assignment5
    Inherits System.Web.UI.Page

    Protected Sub imgbtn1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtn1.Click
        pnl.Visible = True
        img.Visible = True
        img.ImageUrl = sender.ImageUrl
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        pnl.Visible = False
    End Sub

    Protected Sub imgbtn2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtn2.Click
        pnl.Visible = True
        img.Visible = True
        img.ImageUrl = sender.ImageUrl
    End Sub

    Protected Sub imgbtn3_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtn3.Click
        pnl.Visible = True
        img.Visible = True
        img.ImageUrl = sender.ImageUrl
    End Sub

    Protected Sub imgbtn4_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtn4.Click
        pnl.Visible = True
        img.Visible = True
        img.ImageUrl = sender.ImageUrl
    End Sub
End Class
