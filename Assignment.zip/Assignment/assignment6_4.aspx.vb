﻿
Partial Class assignment6_4
    Inherits System.Web.UI.Page

End Class
