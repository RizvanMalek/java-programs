﻿
Partial Class assignment6
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        pnlHome.Visible = True
    End Sub

    Protected Sub btnInsertPage_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnInsertPage.Click
        Response.Redirect("assignment6_2.aspx")
    End Sub

    Protected Sub btnEditPage_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEditPage.Click
        Response.Redirect("assignment6_3.aspx")
    End Sub

    Protected Sub btnAbout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAbout.Click
        Response.Redirect("assignment6.aspx")
    End Sub
End Class
