<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		#img_box:hover
		{
			box-shadow: 10px 10px 10px 10px;
		}
	</style>		
</head>
<body>

	<?php include("connection.php"); ?>

	<!-- HEADER -->
	<?php include("header.php"); ?>
	<!-- HEADER -->

	<?php 
		if(isset($_GET['del']))
		{
			$get_id = $_GET['del'];
			$delete_query = "DELETE FROM tbl_emp WHERE id='$get_id'";
			$delete_result = mysqli_query($conn,$delete_query);
			if($delete_result)
			{
	?>
	<div class="container">
		<div class="row">
			<div class="col-md-12" style="background-color: #d2e4e4;margin-top: 30px;margin-bottom: 30px">
				<div class="alert alert-success" id="box_delete" style="margin-top: 20px">
					<strong>DATA IS SUCCESSFULLY DELETED <strong style="float: right;cursor: pointer;" id="btnDeleteHide">X</strong></strong>
				</div>
			</div>
		</div>
	</div>				
	<?php			
			}
		}
	 ?>


	  <?php 
	  	if(isset($_POST['btnU']))
	  	{
	  		$get_id = $_GET['update'];
			$no = $_POST['txtno'];
			$name = $_POST['txtname'];
			$contact = $_POST['txtcno'];
			$designation = $_POST['txtdesignation'];
			$salary = $_POST['txtsalary'];
			$update_query = "UPDATE tbl_emp SET eno='$no',ename='$name',contact='$contact',designation='$designation',salary='$salary' WHERE id='$get_id'";
			$update_result = mysqli_query($conn,$update_query);
			if($update_result)
			{
				$show_update = 1;
			}				  					
	  	}
	   ?>

	 <?php 
	 	if(isset($_GET['update']))
	 	{
	 		$get_id = $_GET['update'];
	 		$select_query2 = "SELECT * FROM tbl_emp WHERE id='$get_id'";
	 		$select_result2 = mysqli_query($conn,$select_query2);
			$row = mysqli_fetch_array($select_result2);	 		
	?>
	  <div class="container" id="hideupdate">
	  	 <div class="row">
	  	 	<div class="col-md-8 col-md-offset-2" style="border: 1px solid skyblue;margin-top: 30px">
	  	 		<h3>UPDATE EMPLOYEE DETAILS <strong style="float: right;cursor: pointer;" id="btnUpdateHide">X</strong></h3><hr style="border: 1px solid skyblue">
	  	 		<?php 
	  	 			if(isset($show_update))
	  	 			{
	  	 		?>
	  	 		 <div class="alert alert-success" id="alert_box"> 
	  	 		 	<strong>EMPLOYEE DETAILS IS SUCCEESSFULLY UPDATED <strong style="float: right;cursor: pointer;" id="btnalert">X</strong></strong>
	  	 		 </div>

	  	 		<?php
	  	 			}
	  	 		 ?>
				<form method="POST">
					<div class="form-group">
						<label>ENTER EMPLOYEE NO</label>
						<input type="text" value="<?php echo $row[1]; ?>" class="form-control" name="txtno" placeholder="Employee No...." required>
					</div>
					<div class="form-group">
						<label>ENTER EMPLOYEE NAME</label>
						<input type="text" value="<?php echo $row[2]; ?>" class="form-control" name="txtname" placeholder="Employee Name...." required>
					</div>
					<div class="form-group">
						<label>ENTER CONTACT NO</label>
						<input type="text" value="<?php echo $row[3]; ?>" class="form-control" name="txtcno" placeholder="Employee Contact No...." required>
					</div>
					<div class="form-group">
						<label>ENTER EMPLOYEE DESIGNATION</label>
						<input type="text" value="<?php echo $row[4]; ?>" class="form-control" name="txtdesignation" placeholder="Employee Designation...." required>
					</div>
					<div class="form-group">
						<label>ENTER EMPLOYEE SALARY</label>
						<input type="text" value="<?php echo $row[5]; ?>" class="form-control" name="txtsalary" placeholder="Employee Salary...." required>
					</div>
					<div class="form-group">
						<input type="submit" class="btn btn-primary" name="btnU" value="UPDATE EMPLOYEE DETAILS">					
					</div>
				</form>				
	  	 	</div>

	  	 </div>
	  </div>

	<?php
	 	}
	  ?>


	<div class="container">
		<div class="row">
			<div class="col-md-12" style="margin-top: 30px;margin-bottom: 20px" id="img_box">
				<img src="img/img5.jpg" width="100%" style="height: 400px" class="img img-thumbnail">
			</div>
		</div>
	</div>	


	<div class="container">
		<div class="row">
			<div class="col-md-12" style="background-color: #d2e4e4;margin-top: 30px;margin-bottom: 30px">
				<h2>EMPLOYEE DETAILS</h2><hr style="border: 1px solid skyblue">
				<table class="table table-hover table-bordered">
					<tr>
						<th>EMPLOYEE NO</th>
						<th>EMPLOYEE NAME</th>
						<th>CONTACT NO</th>
						<th>DESIGNATION</th>
						<th>SALARY</th>
						<th>ACTION</th>
					</tr>
				<?php 
					$select_query = "SELECT * FROM tbl_emp ORDER BY id ASC";
					$select_result = mysqli_query($conn,$select_query);
					while($row=mysqli_fetch_array($select_result))
					{
				?>
					<tr>
						<td><?php echo $row[1]; ?></td>
						<td><?php echo $row[2]; ?></td>
						<td><?php echo $row[3]; ?></td>
						<td><?php echo $row[4]; ?></td>
						<td><?php echo $row[5]; ?></td>
						<td>
							<a href="edit.php?del=<?php echo $row[0]; ?>" style="color: black;margin-left: 10px"><span class="glyphicon glyphicon-trash"></span></a>
							<a href="edit.php?update=<?php echo $row[0]; ?>" style="color: black;margin-left: 10px"><span class="glyphicon glyphicon-edit"></span></a>
						</td>
					</tr>
				<?php		
					}						
				 ?>		

				</table>
			</div>
		</div>
	</div>

	<!-- FOOTER -->
	<?php include("footer.php"); ?>
	<!-- FOOTER -->




	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#btnDeleteHide').click(function()
			{
				$('#box_delete').hide();
			});
			$('#btnUpdateHide').click(function()
			{
				$('#hideupdate').hide();
			});
			$('#btnalert').click(function(){
				$('#alert_box').hide();	
			});
		});
	</script>
</body>
</html>
