<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		#img_box:hover
		{
			box-shadow: 10px 10px 10px 10px;
		}
	</style>		
</head>
<body>

	<?php include("connection.php"); ?>

	<!-- HEADER -->
	<?php include("header.php"); ?>
	<!-- HEADER -->

	<!-- PHP-CODE -->
	<?php 
		if(isset($_POST['btninsert']))
		{
			$no = $_POST['txtno'];
			$name = $_POST['txtname'];
			$contact = $_POST['txtcno'];
			$designation = $_POST['txtdesignation'];
			$salary = $_POST['txtsalary'];
			$insert_query = "INSERT INTO tbl_emp VALUES('','$no','$name','$contact','$designation','$salary')";
			$insert_result = mysqli_query($conn,$insert_query);
			if($insert_result)
			{
				$show_alert = 1;
			}			
		}
	 ?>
	<!-- PHP-CODE -->

	<!-- CENTER-PAGE -->
	<div class="container">
		<div class="row">
			<div class="col-md-12" style="margin-top: 30px;margin-bottom: 20px" id="img_box">
				<img src="img/img5.jpg" width="100%" style="height: 400px" class="img img-thumbnail">
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<h3 class="text text-center">INSERT EMPLOYEE DETAILS</h3><hr style="border: 1px solid black">
				<?php 
					if(isset($show_alert))
					{
				?>
					<div class="container" id="insertbox">
						<div class="row">
							<div class="col-md-12">
								<div class="alert alert-success">
									<strong>EMPLOYEE DETAILS HAS BEN INSERTED <strong id="btnhide" style="float: right;cursor: pointer;">X</strong></strong>
								</div>
							</div>
						</div>
					</div>
				<?php		
					}
				 ?>				
				<form method="POST">
					<div class="form-group">
						<label>ENTER EMPLOYEE NO</label>
						<input type="text" class="form-control" name="txtno" placeholder="Employee No...." required>
					</div>
					<div class="form-group">
						<label>ENTER EMPLOYEE NAME</label>
						<input type="text" class="form-control" name="txtname" placeholder="Employee Name...." required>
					</div>
					<div class="form-group">
						<label>ENTER CONTACT NO</label>
						<input type="text" class="form-control" name="txtcno" placeholder="Employee Contact No...." required>
					</div>
					<div class="form-group">
						<label>ENTER EMPLOYEE DESIGNATION</label>
						<input type="text" class="form-control" name="txtdesignation" placeholder="Employee Designation...." required>
					</div>
					<div class="form-group">
						<label>ENTER EMPLOYEE SALARY</label>
						<input type="text" class="form-control" name="txtsalary" placeholder="Employee Salary...." required>
					</div>
					<div class="form-group">
						<input type="submit" class="btn btn-primary" name="btninsert" value="SUBMIT EMPLOYEE DETAILS">					
					</div>

				</form>				
			</div>
		</div>
	</div>
	<!-- CENTER-PAGE -->

	<!-- FOOTER -->
	<?php include("footer.php"); ?>
	<!-- FOOTER -->




	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#btnhide').click(function()
			{
				$('#insertbox').hide();
			});

		});
	</script>
</body>
</html>
