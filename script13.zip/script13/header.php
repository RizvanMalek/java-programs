<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		.col-md-2:hover
		{
			border-bottom: 4px solid white;
			transition: 0.4s;
		}
	</style>		
</head>
<body>

	<!-- HEADER -->
	<div class="container-fluid">
		<div class="row" style="background-color: #6cd6cc;border-bottom: 4px solid #6cd6cc">
			 <div class="col-md-6">
			 	<h2><a href="index.php" style="text-decoration: none;color: black">EMPLOYE MANAGEMENT</a><button id="btnhide" style="border: 0px;float: right;background-color: #6cd6cc"><span class="glyphicon glyphicon-th-list"></span></button></h2>
			 </div>
			 <div id="toggle-hide">
			 <div class="col-md-2">
			 	<h3><a href="insert.php" style="text-decoration: none"><span class="glyphicon glyphicon-save"></span>INSERT</a></h3>
			 </div>
			 <div class="col-md-2">
			 	<h3><a href="edit.php" style="text-decoration: none"><span class="glyphicon glyphicon-edit"></span>EDIT</a></h3>
			 </div>
			 <div class="col-md-2">
			 	<h3><a href="search.php" style="text-decoration: none"><span class="glyphicon glyphicon-search"></span>SEARCH</a></h3>
			 </div>
			 </div>
		</div>
	</div>

	<!-- HEADER -->
	
	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			var w = $(window).width();
			$('#btnhide').hide();
			if(w>=100 && w<=600)
			{
				$('#toggle-hide').hide();	
				$('#btnhide').show();
			}	
			$('#btnhide').click(function(){
				$('#toggle-hide').slideToggle();	

			});
		});
	</script>
</body>
</html>
