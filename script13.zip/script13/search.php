<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		#img_box:hover
		{
			box-shadow: 10px 10px 10px 10px;
		}
	</style>		
</head>
<body>

	<?php include("connection.php"); ?>

	<!-- HEADER -->
	<?php include("header.php"); ?>
	<!-- HEADER -->

	<div class="container">
		<div class="row" style="margin-top: 30px">
			<form method="POST">
			<div class="col-md-8">
				<div class="form-group">
					<input type="text" class="form-control" name="txtsearch" placeholder="Search Employee Name.....">
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group">
					<input type="submit" class="btn btn-success" value="SEARCH EMPLOYEE" name="btnsearch">
				</div>
			</div>
			</form>

	<?php 
		if(isset($_POST['btnsearch']))
		{
			$name = mysqli_escape_string($conn,$_POST['txtsearch']);
			$select_query = "SELECT * FROM tbl_emp WHERE ename='$name'";
			$select_result = mysqli_query($conn,$select_query);
			$row = mysqli_fetch_array($select_result);			
	?>

				<h2>SEARCH RESULT......</h2><hr style="border: 1px solid skyblue">
				<table class="table table-hover table-bordered">
					<tr>
						<th>EMPLOYEE NO</th>
						<th>EMPLOYEE NAME</th>
						<th>CONTACT NO</th>
						<th>DESIGNATION</th>
						<th>SALARY</th>
					</tr>
					<tr>
						<td><?php echo $row[1]; ?></td>
						<td><?php echo $row[2]; ?></td>
						<td><?php echo $row[3]; ?></td>
						<td><?php echo $row[4]; ?></td>
						<td><?php echo $row[5]; ?></td>
					</tr>

				</table>


 	<?php

		}

	 ?>		
		</div>
		<div class="row">
			<div class="col-md-12" style="margin-top: 30px;margin-bottom: 20px" id="img_box">
				<img src="img/img5.jpg" width="100%" style="height: 400px" class="img img-thumbnail">
			</div>
		</div>
	</div>	


	<!-- FOOTER -->
	<?php include("footer.php"); ?>
	<!-- FOOTER -->


	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#btnDeleteHide').click(function()
			{
				$('#box_delete').hide();
			});
			$('#btnUpdateHide').click(function()
			{
				$('#hideupdate').hide();
			});
			$('#btnalert').click(function(){
				$('#alert_box').hide();	
			});
		});
	</script>
</body>
</html>
