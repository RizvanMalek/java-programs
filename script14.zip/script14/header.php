<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		.col-md-2
		{
			border-bottom: 4px solid black;			
		}
		.col-md-2:hover
		{
			border-bottom: 4px solid red;
			transition: 0.4s;

		}
	</style>		
</head>
<body>

	<!-- HEADER -->
	<div class="container-fluid">
		<div class="row" style="background-color: black;">
			 <div class="col-md-6" style="border-bottom: 4px solid black">
			 	<h2><a href="index.php" style="text-decoration: none;color: white">COLLEGE MANAGEMENT</a><button id="btnhide" style="border: 0px;float: right;background-color: black;color: white"><span class="glyphicon glyphicon-th-list"></span></button></h2>
			 </div>
			 <div id="toggle-hide">
			 <div class="col-md-2" >
			 	<h3><a href="insert.php" style="text-decoration: none"><span class="glyphicon glyphicon-save"></span>INSERT</a></h3>
			 </div>
			 <div class="col-md-2" >
			 	<h3><a href="edit.php" style="text-decoration: none"><span class="glyphicon glyphicon-edit"></span>EDIT</a></h3>
			 </div>
			 <div class="col-md-2" >
			 	<h3><a href="search.php" style="text-decoration: none"><span class="glyphicon glyphicon-search"></span>SEARCH</a></h3>
			 </div>
			 </div>
		</div>
	</div>

	<!-- HEADER -->
	
	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			var w = $(window).width();
			$('#btnhide').hide();
			if(w>=100 && w<=800)
			{
				$('#toggle-hide').hide();	
				$('#btnhide').show();
			}	
			$('#btnhide').click(function(){
				$('#toggle-hide').slideToggle();	

			});
		});
	</script>
</body>
</html>
