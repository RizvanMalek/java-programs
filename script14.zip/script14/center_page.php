<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		.col-md-4
		{
			padding-top: 10px; 
		}
		.col-md-4:hover
		{
			box-shadow: 10px 10px 10px 10px;
		}
		#img_box:hover
		{
			box-shadow: 10px 10px 10px 10px;
		}
	</style>		
</head>
<body>

	<!-- CENTER-PAGE -->
	<div class="container">
		<div class="row">
			<div class="col-md-12" style="margin-top: 30px;margin-bottom: 20px" id="img_box">
				<img src="img/img3.jpg" width="100%" style="height: 400px" class="img img-thumbnail">
			</div>
		</div>
		<div class="row" style="margin-top: 10px">
			<div class="col-md-4">
				<div class="jumbotron" style="padding: 20px">
					 <img src="img/img2.jpg" width="100%" style="height: 200px" class="img img-thumbnail">
					 <div style="margin-top: 10px">
						 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						 tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						 quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						 consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						 cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						 proident, sunt in culpa qui officia deserunt mollit anim id est laborum.					 	
					 </div><br>
					 <div class="form-group">
						<a href="insert.php" class="btn btn-info btn-block">INSERT</a>					 	
					 </div>
				</div>
			</div>
	
		<div class="col-md-4">
				<div class="jumbotron" style="padding: 20px">
					 <img src="img/img5.jpg" width="100%" style="height: 200px" class="img img-thumbnail">
					 <div style="margin-top: 10px">
						 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						 tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						 quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						 consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						 cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						 proident, sunt in culpa qui officia deserunt mollit anim id est laborum.					 	
					 </div><br>
					 <div class="form-group">
						<a href="edit.php" class="btn btn-primary btn-block">EDIT</a>					 	
					 </div>
				</div>
			</div>
	
		<div class="col-md-4">
				<div class="jumbotron" style="padding: 20px">
					 <img src="img/img4.jpg" width="100%" style="height: 200px" class="img img-thumbnail">
					 <div style="margin-top: 10px">
						 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						 tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						 quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						 consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						 cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						 proident, sunt in culpa qui officia deserunt mollit anim id est laborum.					 	
					 </div><br>
					 <div class="form-group">
						<a href="search.php" class="btn btn-success btn-block">SEARCH</a>					 	
					 </div>
				</div>
			</div>	
		</div>



	</div>
	<!-- CENTER-PAGE -->


	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
