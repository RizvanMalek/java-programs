<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
	</style>		
</head>
<body>

	<div class="container-fluid">
		<div class="row" style="background-color: black;color: white">
			<div class="col-md-12">
				<h3 class="text text-center">THIS WEBSITE IS CREATED BY RIZVAN | 2019</h3>
			</div>
		</div>
	</div>


	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
