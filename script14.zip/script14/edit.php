<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		#img_box:hover
		{
			box-shadow: 10px 10px 10px 10px;
		}
	</style>		
</head>
<body>

	<?php include("connection.php"); ?>

	<!-- HEADER -->
	<?php include("header.php"); ?>
	<!-- HEADER -->

	<?php 
		if(isset($_GET['del']))
		{
			$get_id = $_GET['del'];
			$delete_query = "DELETE FROM tbl_college WHERE id='$get_id'";
			$delete_result = mysqli_query($conn,$delete_query);
			if($delete_result)
			{
	?>
	<div class="container">
		<div class="row">
			<div class="col-md-12" style="background-color: #d2e4e4;margin-top: 30px;margin-bottom: 30px">
				<div class="alert alert-success" id="box_delete" style="margin-top: 20px">
					<strong>DATA IS SUCCESSFULLY DELETED <strong style="float: right;cursor: pointer;" id="btnDeleteHide">X</strong></strong>
				</div>
			</div>
		</div>
	</div>				
	<?php			
			}
		}
	 ?>


	  <?php 
	  	if(isset($_POST['btnU']))
	  	{
	  		$get_id = $_GET['update'];
			$no = $_POST['txtno'];
			$name = $_POST['txtname'];
			$contact = $_POST['txtcontact'];
			$address = $_POST['txtaddress'];
			$courseoffer = $_POST['txtcourseoffer'];
			$fees = $_POST['txtfees'];
			$update_query = "UPDATE tbl_college SET cno='$no',name='$name',contact='$contact',address='$address',courseoffer='$courseoffer',fees='$fees' WHERE id='$get_id'";
			$update_result = mysqli_query($conn,$update_query);
			if($update_result)
			{
				$show_update = 1;
			}				  					
	  	}
	   ?>

	 <?php 
	 	if(isset($_GET['update']))
	 	{
	 		$get_id = $_GET['update'];
	 		$select_query2 = "SELECT * FROM tbl_college WHERE id='$get_id'";
	 		$select_result2 = mysqli_query($conn,$select_query2);
			$row = mysqli_fetch_array($select_result2);	 		
	?>
	  <div class="container" id="hideupdate">
	  	 <div class="row">
	  	 	<div class="col-md-8 col-md-offset-2" style="border: 1px solid skyblue;margin-top: 30px">
	  	 		<h3>UPDATE COLLEGE DETAILS <strong style="float: right;cursor: pointer;" id="btnUpdateHide">X</strong></h3><hr style="border: 1px solid skyblue">
	  	 		<?php 
	  	 			if(isset($show_update))
	  	 			{
	  	 		?>
	  	 		 <div class="alert alert-success" id="alert_box"> 
	  	 		 	<strong>COLLEGE DETAILS IS SUCCEESSFULLY UPDATED <strong style="float: right;cursor: pointer;" id="btnalert">X</strong></strong>
	  	 		 </div>

	  	 		<?php
	  	 			}
	  	 		 ?>
				<form method="POST">
					<div class="form-group">
						<label>ENTER COLLEGE NO</label>
						<input type="text" class="form-control" value="<?php echo $row[1]; ?>" name="txtno" placeholder="College No....." required>
					</div>					
					<div class="form-group">
						<label>ENTER COLLEGE NAME</label>
						<input type="text" class="form-control" value="<?php echo $row[2]; ?>" name="txtname" placeholder="College Name....." required>
					</div>					
					<div class="form-group">
						<label>ENTER COLLEGE CONTACT NO</label>
						<input type="text" class="form-control" value="<?php echo $row[3]; ?>" name="txtcontact" placeholder="College Contact No....." required>
					</div>					
					<div class="form-group">
						<label>ENTER COLLEGE ADDRESS</label>
						<textarea name="txtaddress" placeholder="Enter College Address..." class="form-control" required><?php echo $row[4]; ?></textarea>							
					</div>					
					<div class="form-group">
						<label>ENTER COURSE OFFER</label>
						<input type="text" value="<?php echo $row[5]; ?>" class="form-control" name="txtcourseoffer" placeholder="College Courser Offer....." required>
					</div>					
					<div class="form-group">
						<label>ENTER COURSE FEES</label>
						<input type="text" class="form-control" value="<?php echo $row[6]; ?>" name="txtfees" placeholder="College Course Fees....." required>
					</div>					
					<div class="form-group">
						<input type="submit" class="btn btn-primary" value="SUBMIT COLLLEGE DETAILS" name="btnU">
					</div>					
				</form>				
	  	 	</div>

	  	 </div>
	  </div>

	<?php
	 	}
	  ?>


	<div class="container">
		<div class="row">
			<div class="col-md-12" style="margin-top: 30px;margin-bottom: 20px" id="img_box">
				<img src="img/img5.jpg" width="100%" style="height: 400px" class="img img-thumbnail">
			</div>
		</div>
	</div>	


	<div class="container">
		<div class="row">
			<div class="col-md-12" style="background-color: #d2e4e4;margin-top: 30px;margin-bottom: 30px">
				<h2>COLLEGE DETAILS</h2><hr style="border: 1px solid skyblue">
				<table class="table table-hover table-bordered">
					<tr>
						<th>COLLEGE NO</th>
						<th>COLLEGE NAME</th>
						<th>CONTACT NO</th>
						<th>ADDRESS</th>
						<th>COURSE OFFER</th>
						<th>FEES</th>
						<th>ACTION</th>
					</tr>
				<?php 
					$select_query = "SELECT * FROM tbl_college ORDER BY id ASC";
					$select_result = mysqli_query($conn,$select_query);
					while($row=mysqli_fetch_array($select_result))
					{
				?>
					<tr>
						<td><?php echo $row[1]; ?></td>
						<td><?php echo $row[2]; ?></td>
						<td><?php echo $row[3]; ?></td>
						<td><?php echo $row[4]; ?></td>
						<td><?php echo $row[5]; ?></td>
						<td><?php echo $row[6]; ?></td>
						<td>
							<a href="edit.php?del=<?php echo $row[0]; ?>" style="color: black;margin-left: 10px"><span class="glyphicon glyphicon-trash"></span></a>
							<a href="edit.php?update=<?php echo $row[0]; ?>" style="color: black;margin-left: 10px"><span class="glyphicon glyphicon-edit"></span></a>
						</td>
					</tr>
				<?php		
					}						
				 ?>		

				</table>
			</div>
		</div>
	</div>

	<!-- FOOTER -->
	<?php include("footer.php"); ?>
	<!-- FOOTER -->




	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#btnDeleteHide').click(function()
			{
				$('#box_delete').hide();
			});
			$('#btnUpdateHide').click(function()
			{
				$('#hideupdate').hide();
			});
			$('#btnalert').click(function(){
				$('#alert_box').hide();	
			});
		});
	</script>
</body>
</html>
