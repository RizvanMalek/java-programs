<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
</head>
<body>

	<!-- HEADER -->
	<?php include("header.php"); ?>
	<!-- HEADER -->

	<!-- CENTER-PAGE -->
	<?php include("center_page.php"); ?>
	<!-- CENTER-PAGE -->

	<!-- FOOTER -->
	<?php include("footer.php"); ?>
	<!-- FOOTER -->
	
	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
