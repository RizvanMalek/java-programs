<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		#t:hover
		{
			box-shadow: 5px 5px 5px 5px;
		}
	</style>
</head>
<body>

	<?php include("connection.php"); ?>
	<!-- HEADER -->
	<?php include("header.php"); ?>
	<!-- HEADER -->

	<?php 
		if(isset($_POST['btninsert']))
		{
			$no = $_POST['txtno'];
			$name = $_POST['txtname'];
			$contact = $_POST['txtcontact'];
			$address = $_POST['txtaddress'];
			$courseoffer = $_POST['txtcourseoffer'];
			$fees = $_POST['txtfees'];
			$insert_query = "INSERT INTO tbl_college VALUES('','$no','$name','$contact','$address','$courseoffer','$fees')";
			$insert_result = mysqli_query($conn,$insert_query);
			if($insert_result)
			{
				$show_insert = 1;
			}			
		}

	 ?>


	<!-- CENTER-PAGE -->
	<div class="container-fluid">
		<div class="row" style="margin-top: 30px;margin-bottom: 40px">
			<div class="col-md-5">
				<img src="img/img4.jpg" id="t" width="100%" style="height: 600px">
			</div>
			<div class="col-md-7">
				<h3>INSERT COLLEGE INFORMATION</h3><hr style="border: 1px solid orange">
				<?php 
					if(isset($show_insert))
					{
				?>
					<div id="hide_box" class="alert alert-success">
						<strong>DATA IS SUCCESSFULLY INSERTED</strong><strong id="hidebtn" style="float: right;cursor: pointer;">X</strong> 
					</div>
				<?php		
					}
				 ?>				
				<form method="POST">
					<div class="form-group">
						<label>ENTER COLLEGE NO</label>
						<input type="text" class="form-control" name="txtno" placeholder="College No....." required>
					</div>					
					<div class="form-group">
						<label>ENTER COLLEGE NAME</label>
						<input type="text" class="form-control" name="txtname" placeholder="College Name....." required>
					</div>					
					<div class="form-group">
						<label>ENTER COLLEGE CONTACT NO</label>
						<input type="text" class="form-control" name="txtcontact" placeholder="College Contact No....." required>
					</div>					
					<div class="form-group">
						<label>ENTER COLLEGE ADDRESS</label>
						<textarea name="txtaddress" placeholder="Enter College Address..." class="form-control" required></textarea>							
					</div>					
					<div class="form-group">
						<label>ENTER COURSE OFFER</label>
						<input type="text" class="form-control" name="txtcourseoffer" placeholder="College Courser Offer....." required>
					</div>					
					<div class="form-group">
						<label>ENTER COURSE FEES</label>
						<input type="text" class="form-control" name="txtfees" placeholder="College Course Fees....." required>
					</div>					
					<div class="form-group">
						<input type="submit" class="btn btn-primary" value="SUBMIT COLLLEGE DETAILS" name="btninsert">
					</div>					

				</form>				
			</div>
		</div>
	</div>
	<!-- CENTER-PAGE -->

	<!-- FOOTER -->
	<?php include("footer.php"); ?>
	<!-- FOOTER -->
	
	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#hidebtn').click(function()
			{
				$('#hide_box').hide();
			});
		});
	</script>
</body>
</html>
