<!DOCTYPE html>
<html>
<head>
	<title>home</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
	.col-md-4
	{
		padding-top: 10px;
	}
	#t:hover
	{
		border-radius: 20px;
		box-shadow: 10px 10px 10px 10px;
	}

	</style>	
</head>
<body>

	<div class="container">
		<div class="row" style="margin-top: 20px;margin-bottom: 20px">
			<div class="col-md-4" id="t">
				<div class="jumbotron" style="padding: 10px">
					<img src="img/img1.jpg" style="width: 100%">
					<div style="font-size: 20px">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
					</div>
					<div class="form-group">
						<a href="insert.php" class="btn btn-primary btn-block"><span class="glyphicon glyphicon-cloud-upload"> INSERT</span></a>	
					</div>
				</div>
			</div>

			<div class="col-md-4" id="t">
				<div class="jumbotron" style="padding: 10px">
					<img src="img/background.jpg" style="width: 100%">
					<div style="font-size: 20px">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
					</div>
					<div class="form-group">
						<a href="edit.php" class="btn btn-info btn-block"><span class="glyphicon glyphicon-edit"> EDIT</span></a>	
					</div>
				</div>
			</div>
			<div class="col-md-4" id="t">
				<div class="jumbotron" style="padding: 10px">
					<img src="img/img2.jpg" style="width: 100%">
					<div style="font-size: 20px">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
					</div>
					<div class="form-group">
						<a href="search.php" class="btn btn-warning btn-block"><span class="glyphicon glyphicon-search"> SEARCH</span></a>	
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-md-12" style="background-color: grey" align="center">
				<h3>ABOUT THIS SITE</h3>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div style="font-size: 20px">
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
				</div>								
			</div>
		</div>
	</div>

	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>	
	<script type="text/javascript">
		$(document).ready(function(){
		});
	</script>
</body>
</html>