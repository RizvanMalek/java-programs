-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 18, 2019 at 01:18 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `as`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_book`
--

CREATE TABLE IF NOT EXISTS `tbl_book` (
  `id` int(100) NOT NULL,
  `code` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `isbn` int(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_book`
--

INSERT INTO `tbl_book` (`id`, `code`, `name`, `author`, `price`, `isbn`) VALUES
(5, 101, 'C', 'BalaGuru Swami', '550', 7897),
(6, 102, 'c++', 'Syam Chavda', '650', 786),
(7, 103, 'vb.net', 'Syam Chavda', '450', 876),
(8, 104, 'Python', 'Atul Jalan', '760', 5678);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_college`
--

CREATE TABLE IF NOT EXISTS `tbl_college` (
  `id` int(100) NOT NULL,
  `cno` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact` int(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `courseoffer` varchar(100) NOT NULL,
  `fees` int(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_college`
--

INSERT INTO `tbl_college` (`id`, `cno`, `name`, `contact`, `address`, `courseoffer`, `fees`) VALUES
(3, 208, 'v.t.poddar bca college', 2147483647, 'Pramukh Park Brc Road Pandesara Surat Gujrat', 'BCA', 15000),
(4, 102, 'SDJ INTERNATIONAL COLLEGE', 2147483647, 'At Vip Road Vesu Surat Gujrat', 'Bca', 15000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company`
--

CREATE TABLE IF NOT EXISTS `tbl_company` (
  `id` int(100) NOT NULL,
  `no` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact` int(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `emp` int(100) NOT NULL,
  `estyear` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_company`
--

INSERT INTO `tbl_company` (`id`, `no`, `name`, `contact`, `address`, `emp`, `estyear`) VALUES
(1, 101, 'INFO RIZVAN PVT LTD', 2147483647, 'Gopipura Momnawad Surat Gujrat India', 1000, '2022-01-01'),
(4, 301, 'Infosis', 2147483647, 'Chok Road At Banglore India', 450, '1996-06-04'),
(5, 504, 'Wipro', 213408765, 'Pul Chock New Road Pune India', 550, '2005-07-13');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_emp`
--

CREATE TABLE IF NOT EXISTS `tbl_emp` (
  `id` int(100) NOT NULL,
  `eno` int(100) NOT NULL,
  `ename` varchar(100) NOT NULL,
  `contact` int(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `salary` int(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_emp`
--

INSERT INTO `tbl_emp` (`id`, `eno`, `ename`, `contact`, `designation`, `salary`) VALUES
(6, 201, 'Riya Jain', 99, 'PO', 50),
(7, 202, 'Rizvan', 2147483647, 'Junior Asistance', 10000),
(8, 203, 'Ajay', 2147483647, 'Senior Manager', 45000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE IF NOT EXISTS `tbl_product` (
  `id` int(100) NOT NULL,
  `pno` int(100) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `pcatgry` varchar(100) NOT NULL,
  `pimg` varchar(100) NOT NULL,
  `pprice` int(100) NOT NULL,
  `pqty` int(100) NOT NULL,
  `ptotal` int(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `pno`, `pname`, `pcatgry`, `pimg`, `pprice`, `pqty`, `ptotal`) VALUES
(2, 101, 'Apple', 'Froots', '', 15, 150, 2250),
(3, 102, 'Banana', 'Froots', '', 10, 250, 2500);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE IF NOT EXISTS `tbl_student` (
  `id` int(100) NOT NULL,
  `sno` int(100) NOT NULL,
  `eno` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `contactno` int(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`id`, `sno`, `eno`, `name`, `gender`, `age`, `contactno`) VALUES
(1, 1, 1001, 'Rizvan Malek', 'MALE', '20', 2147483647),
(2, 2, 1002, 'Pankaj Danej', 'MALE', '21', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mno` int(100) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `gender`, `email`, `password`, `mno`, `address`) VALUES
(1, 'Rizvan Malek', 'Male', 'malek@gmail.com', '12345', 2147483647, 'Gopipura SagramPura Surat Gujrat'),
(2, 'Pankaj Danej', 'Male', 'pankaj@gmail.com', '66654445', 2147483647, 'Pandesara Surat Gujrat');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_book`
--
ALTER TABLE `tbl_book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_college`
--
ALTER TABLE `tbl_college`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_company`
--
ALTER TABLE `tbl_company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_emp`
--
ALTER TABLE `tbl_emp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_book`
--
ALTER TABLE `tbl_book`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_college`
--
ALTER TABLE `tbl_college`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_company`
--
ALTER TABLE `tbl_company`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_emp`
--
ALTER TABLE `tbl_emp`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_student`
--
ALTER TABLE `tbl_student`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
