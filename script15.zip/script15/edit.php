<!DOCTYPE html>
<html>
<head>
	<title>home</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		#update_input:hover
		{
			box-shadow: 5px 5px 5px 5px;
		}
	</style>	
</head>
<body>
	<?php include("connection.php"); ?>


	<!-- HEADER -->
	<?php include("header.php"); ?>	
	<!-- HEADER -->

	<?php 
		if(isset($_GET['del']))
		{
			$get_id = $_GET['del'];
			$delete_query = "DELETE FROM tbl_company WHERE id='$get_id'";
			$delete_result = mysqli_query($conn,$delete_query);
			if($delete_result)
			{
				$delet_t = 1;
			}			
		}
	 ?>

	 <?php 
	 	if(isset($_POST['btnupdate']))
	 	{
	 		$get_id = $_GET['update'];
			$no = $_POST['txtno'];
			$name = $_POST['txtname'];
			$contact = $_POST['txtcontact'];
			$address = $_POST['txtaddress'];
			$emp = $_POST['txtemp'];
			$year = $_POST['txtyear'];
			$update_query = "UPDATE tbl_company SET no='$no',name='$name',contact='$contact',address='$address',emp='$emp',estyear='$year' WHERE id='$get_id'";
			$update_result = mysqli_query($conn,$update_query);
			if($update_result)
			{
				$update_t = 1;
			}							 						
	 	}
	  ?>

	 <?php 
	 	if(isset($_GET['update']))
	 	{
	 		$get_id = $_GET['update'];
	 		$select_query2 = "SELECT * FROM tbl_company WHERE id='$get_id'";
	 		$select_result2 = mysqli_query($conn,$select_query2);
	 		$row = mysqli_fetch_array($select_result2);
	 ?>
	 <div class="container" >
	 	<div class="row">
	 		<div class="col-md-6 col-md-offset-3" id="update_input" style="margin-top: 30px;margin-bottom: 20px">
			<form method="POST">
				<h3>UPDATE | EDIT COMPANY DETAILS <strong id="btnHideUpdate" style="float: right;cursor: pointer;">X</strong> </h3><hr style="border: 1px solid skyblue;">
				<div id="close" class="alert alert-success">
					<strong>DATA IS SUCCESSFULLY UPDATED</strong><strong id="btnH" style="float: right;cursor: pointer;">X</strong>
				</div>
				<div class="form-group">
					<label>ENTER COMPANY REGISTER NO</label>
					<input type="text" value="<?php echo $row[1]; ?>" class="form-control" name="txtno" placeholder="Company No...." required>
				</div>
				<div class="form-group">
					<label>ENTER COMPANY NAME</label>
					<input type="text" value="<?php echo $row[2]; ?>" class="form-control" name="txtname" placeholder="Company Name...." required>
				</div>
				<div class="form-group">
					<label>ENTER COMPANY CONTACT NO</label>
					<input type="text" value="<?php echo $row[3]; ?>" class="form-control" name="txtcontact" placeholder="Company Contact No...." required>
				</div>					
				<div class="form-group">
					<label>ENTER COMPANY ADDRESS</label>
					<textarea class="form-control" name="txtaddress" required><?php echo $row[4]; ?></textarea>							
				</div>
				<div class="form-group">
					<label>ENTER NUMBER OF EMPLOYEES WORK IN COMAPNY</label>
					<input type="text" value="<?php echo $row[5]; ?>" class="form-control" name="txtemp" placeholder="Company Employees...." required>
				</div>
				<div class="form-group">
					<label>ENTER COMPANY EXTABLISH YEAR</label>
					<input type="date" value="<?php echo $row[6]; ?>" class="form-control" name="txtyear" placeholder="Company No...." required>
				</div>						
				<div class="form-group">
					<input type="submit" class="btn btn-primary" value="SUBMIT COMPANY DETAILS" name="btnupdate">
					</div>
				</form>	 			
	 		</div>
	 	</div>
	 </div>


	 <?php	
	 	}

	  ?>


	<div class="container">
		<div class="row">
			<div class="co-md-12">
				<h3>COMPANY DETAILS</h3><hr style="border: 1px solid skyblue">
				<?php 
					if(isset($delet_t))
					{
				?>
				<div id="hideDelete" class="alert alert-success">
					<strong>DATA IS SUCCESSFULLY DELETED</strong><strong id="btnDelete" style="float: right;cursor: pointer;">X</strong>
				</div>				

				<?php		
					}
				 ?>
				<table class="table table-hover table-bordered">
					<tr>
						<th>COMPANY NO</th>
						<th>COMPANY NAME</th>
						<th>COMPANY CONTACT NO</th>
						<th>ADDRESS</th>
						<th>NUMBER OF EMPLOYEE</th>
						<th>ESTABLISH YEAR</th>
						<th>ACTION</th>
					</tr>
				<?php 
					$select_query = "SELECT * FROM tbl_company ORDER BY id ASC";
					$select_result = mysqli_query($conn,$select_query);
					while($row=mysqli_fetch_array($select_result))
					{
				?>
					<tr>
						<td><?php echo $row[1]; ?></td>
						<td><?php echo $row[2]; ?></td>
						<td><?php echo $row[3]; ?></td>
						<td><?php echo $row[4]; ?></td>
						<td><?php echo $row[5]; ?></td>
						<td><?php echo $row[6]; ?></td>
						<td>
							<a href="edit.php?del=<?php echo $row[0]; ?>" style="color: black"><span class="glyphicon glyphicon-trash"></span></a>
							<a href="edit.php?update=<?php echo $row[0]; ?>" style="color: black;margin-left: 10px"><span class="glyphicon glyphicon-edit"></span></a>
						</td>
					</tr>
				<?php		
					}												
				 ?>		
				</table>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="row">
			<div class="col-md-12" style="background-color: grey" align="center">
				<h3>ABOUT THIS SITE</h3>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div style="font-size: 20px">
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
				</div>								
			</div>
		</div>
	</div>
		
	</div>
	<!-- FOOTER -->
	<?php include("footer.php"); ?>	
	<!-- FOOTER -->

	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>	
	<script type="text/javascript">
		$(document).ready(function(){
			$('#btnDelete').click(function(){
				$('#hideDelete').hide();
			});
			$('#btnHideUpdate').click(function(){
				$('#update_input').hide();	
			});
			$('#btnH').click(function(){
				$('#close').hide();	
			});
		});
	</script>
</body>
</html>