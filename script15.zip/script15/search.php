<!DOCTYPE html>
<html>
<head>
	<title>home</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
	
	<?php include("connection.php"); ?>
	<!-- HEADER -->
	<?php include("header.php"); ?>
	<!-- HEADER -->

	<!-- CENTER-PAGE -->
	<div class="container">
		<div class="row" style="margin-top: 40px">
			<form method="POST">
			<div class="col-md-8">
				<div class="form-group">
					<input type="text" class="form-control" name="txtsearch" placeholder="Enter Company Name....." required>
				</div>
			</div>
			<div class="col-md-4">	
				<div class="form-group">
					<button id="btnsearch" name="btnsearch" class="btn btn-default"><span class="glyphicon glyphicon-search"></span></button>
				</div>				
			</div>
			</form>
		</div>
		<div class="row">
			<div class="col-md-12" style="background-color: grey" align="center">
				<h3>ABOUT THIS SITE</h3>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div style="font-size: 20px">
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
				</div>								
			</div>
		</div>
	</div>

		
	</div>
	<!-- CENTER-PAGE -->

	<?php 
	
		if(isset($_POST['btnsearch']))
		{
			$name = mysqli_escape_string($conn,$_POST['txtsearch']);
			$select_query = "SELECT * FROM tbl_company WHERE name='$name'";
			$select_result = mysqli_query($conn,$select_query);
			$row = mysqli_fetch_array($select_result);						
	?>

	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<table class="table table-hover table-bordered">
					<tr>
						<th>COMPANY NO</th>
						<th>COMPANY NAME</th>
						<th>COMPANY CONTACT NO</th>
						<th>ADDRESS</th>
						<th>NUMBER OF EMPLOYEE</th>
						<th>ESTABLISH YEAR</th>
					</tr>
					<tr>
						<td><?php echo $row[1]; ?></td>
						<td><?php echo $row[2]; ?></td>
						<td><?php echo $row[3]; ?></td>
						<td><?php echo $row[4]; ?></td>
						<td><?php echo $row[5]; ?></td>
						<td><?php echo $row[6]; ?></td>
					</tr>
				</table>				
			</div>
		</div>
	</div>

	<?php	
		}
	 ?>

	<!-- FOOTER -->
	<?php include("footer.php"); ?>
	<!-- FOOTER -->
	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>	
</body>
</html>