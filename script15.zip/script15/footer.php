<!DOCTYPE html>
<html>
<head>
	<title>home</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">

	</style>	
</head>
<body>

	<div class="container-fluid" style="background-color: black">
		<div class="row">
			<div class="col-md-4" style="margin-top: 10px">
				 <img src="img/img1.jpg" style="width: 100%;border-radius: 30px">
			</div>
			<div class="col-md-8" style="font-size: 20px;margin-top: 20px;color: white">
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</div>

		</div><hr>
		<div class="row">
			<div class="col-md-12" style="color: white;text-align: center">
				<h3>THIS SITE IS CREATED BY RIZVAN | 2019-20</h3>
			</div>
		</div>
	</div>

	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>	
	<script type="text/javascript">
		$(document).ready(function(){
		});
	</script>
</body>
</html>