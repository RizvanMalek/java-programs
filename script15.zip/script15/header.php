<!DOCTYPE html>
<html>
<head>
	<title>home</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		.col-md-2 a
		{
			font-size: 20px;
			color: white;
		}
		.col-md-2 a:hover
		{
			color: white;	
		}
		#col:hover
		{
			background-color: #1c5156;
		}
	</style>	
</head>
<body>

	<!-- HEADER -->
	<div class="container-fluid">
		<div class="row" style="background-color: black" id="tab">
			<div class="col-md-12" align="center">
				<button id="btnTab" style="background-color: black;border: 0px;color: white;font-size: 20px"><span class="glyphicon glyphicon-list"></span></button>
			</div>
		</div>
		<div class="row" style="background-color: black" align="center">
			<div id="tabshow">
			<div class="col-md-2" id="col">
				<a href="index.php"><span class="glyphicon glyphicon-home"></span></a>
			</div>
			<div class="col-md-2" id="col">
				<a href="insert.php"><span class="glyphicon glyphicon-cloud-upload"></span></a>
			</div>
			<div class="col-md-2" id="col">
				<a href="edit.php"><span class="glyphicon glyphicon-edit"></span></a>
			</div>			
			<div class="col-md-2" id="col">
				<a href="search.php"><span class="glyphicon glyphicon-search"></span></a>
			</div>						
			<div class="col-md-2" id="col">
				<a href="index.php"><span class="glyphicon glyphicon-phone-alt"></span></a>
			</div>						
			<div class="col-md-2" id="col">
				<a href="index.php"><span class="glyphicon glyphicon-info-sign"></span></a>
			</div>			
			</div>			
		</div>
		<div class="row" style="background-color: #6bd4ca">
			<div class="col-md-6">
				<h2><a href="index.php" style="text-decoration: none;color: white">COMPANY MANAGEMENT</a></h2>
			</div>
			<div class="col-md-4" >
				<form method="POST">
				<div class="form-group">
					<input type="text" name="txtsearch" style="margin-top: 15px" class="form-control" name="txtsearch" placeholder="Enter Company Name....">
				</div>
			</div>
			<div class="col-md-2" >
				<div class="form-group">
					<button name="btnSearch" style="margin-top: 23px;height: 35px;border: 0px;background-color: white" class="btn btn-block"><span class="glyphicon glyphicon-search"></span></button>					
				</div>
				</form>				
			</div>
		</div>
	</div>
	<!-- HEADER -->
	<?php 
	if(isset($_POST['btnSearch']))
	{
		header("location:http://localhost/assignment/script15/search.php");
	}
	 ?>
	

	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>	
	<script type="text/javascript">
		$(document).ready(function(){
			$('#tab').hide();
			var w = $(window).width();			
			if(w>=1 && w<=800)
			{
				$('#tabshow').hide();
				$('#tab').show();
				$('#btnTab').click(function(){
					$('#tabshow').slideToggle();	
				});
			}
		});
	</script>
</body>
</html>