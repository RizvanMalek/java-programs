<!DOCTYPE html>
<html>
<head>
	<title>home</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
	</style>	
</head>
<body>
	<?php include("connection.php"); ?>


	<!-- HEADER -->
	<?php include("header.php"); ?>	
	<!-- HEADER -->

	<?php 
		if(isset($_POST['btninsert']))
		{
			$no = $_POST['txtno'];
			$name = $_POST['txtname'];
			$contact = $_POST['txtcontact'];
			$address = $_POST['txtaddress'];
			$emp = $_POST['txtemp'];
			$year = $_POST['txtyear'];
			$insert_query = "INSERT INTO tbl_company VALUES('','$no','$name','$contact','$address','$emp','$year')";
			$insert_result = mysqli_query($conn,$insert_query);
			if($insert_result)
			{
				$show_alert = 1;
			}			

		}

	 ?>

	<!-- CENTER-PAGE -->
	<div class="container" style="margin-top: 30px;margin-bottom: 30px">
		<div class="row">
			<div class="col-md-12">
				<h3>INSERT COMPANY DETAILS</h3><hr style="border: 1px solid skyblue">
				<div class="row">
					<div class="col-md-6 col-md-offset-3">
						<?php 
							if(isset($show_alert))
							{
						?>
						<div class="alert alert-success" id="box">
							<strong>DATA HAS BEEN SUCCESSFULLY INSERTED</strong><strong style="float: right;cursor: pointer;" id="btnhide">X</strong>
						</div>

						<?php		
							}
						 ?>
						<form method="POST">
						<div class="form-group">
							<label>ENTER COMPANY REGISTER NO</label>
							<input type="text" class="form-control" name="txtno" placeholder="Company No...." required>
						</div>
						<div class="form-group">
							<label>ENTER COMPANY NAME</label>
							<input type="text" class="form-control" name="txtname" placeholder="Company Name...." required>
						</div>
						<div class="form-group">
							<label>ENTER COMPANY CONTACT NO</label>
							<input type="text" class="form-control" name="txtcontact" placeholder="Company Contact No...." required>
						</div>					
						<div class="form-group">
							<label>ENTER COMPANY ADDRESS</label>
							<textarea class="form-control" name="txtaddress" required></textarea>							
						</div>
						<div class="form-group">
							<label>ENTER NUMBER OF EMPLOYEES WORK IN COMAPNY</label>
							<input type="text" class="form-control" name="txtemp" placeholder="Company Employees...." required>
						</div>
						<div class="form-group">
							<label>ENTER COMPANY EXTABLISH YEAR</label>
							<input type="date" class="form-control" name="txtyear" placeholder="Company No...." required>
						</div>						
						<div class="form-group">
							<input type="submit" class="btn btn-primary" value="SUBMIT COMPANY DETAILS" name="btninsert">
						</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- CENTER-PAGE -->
		<div class="row">
			<div class="col-md-12" style="background-color: grey" align="center">
				<h3>ABOUT THIS SITE</h3>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div style="font-size: 20px">
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
				</div>								
			</div>
		</div>
	</div>

	<!-- FOOTER -->
	<?php include("footer.php"); ?>	
	<!-- FOOTER -->

	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>	
	<script type="text/javascript">
		$(document).ready(function(){
			$('#btnhide').click(function(){
				$('#box').hide();
			});
		});
	</script>
</body>
</html>