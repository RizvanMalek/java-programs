<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
	</style>
</head>
<body>

	<?php include_once("connection.php"); ?>

	<!-- HEADER -->
	<?php include_once("header.php"); ?>
	<!-- HEADER -->

	<!-- CENTER-PAGE -->
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div align="center">
					<h3>SEARCH BOOK</h3><hr style="border: 1px solid grey">
				</div>
				
				<div class="row">
					<div class="col-md-8">
						<form method="POST">
						 <div class="form-group">							
						 	<input type="text" class="form-control" name="txtsearch" placeholder="Enter Book Here.....">			
						 </div>
					</div>
					<div class="col-md-4">
							<input type="submit" class="btn btn-primary" value="SEARCH.." name="btnsearch">
					</div>
					</form>	
				</div>
			</div>
		</div>
	</div>
	<?php 
		if(isset($_POST['btnsearch']))
		{
			$name = $_POST['txtsearch'];
			$select_query = "SELECT * FROM tbl_book WHERE name='$name'";
			$select_result = mysqli_query($conn,$select_query);			
			$row = mysqli_fetch_array($select_result);			
	?>


	  	<div class="container" style="margin-top: 20px;margin-bottom: 30px">
	  		<div class="row"> 
	  			 <div class="col-md-12">
	  			 	<h3 class="text text-center">SEARCH RESULT......</h3><hr style="border: 1px solid black">
				<table class="table table-hover">
					<tr>
						<th>CODE</th>
						<th>NAME</th>
						<th>AUTHOR</th>
						<th>PRICE</th>
						<th>ISBN CODE</th>
					</tr>
						<tr>
							<td><?php echo $row[1]; ?></td>
							<td><?php echo $row[2]; ?></td>
							<td><?php echo $row[3]; ?></td>
							<td><?php echo $row[4]; ?></td>
							<td><?php echo $row[5]; ?></td>
						</tr>
				</table>		 		


	  			 </div>
	  		</div>
	  	</div>
	<?php
		}
		else
		{
	?>
		<div class="container" style="height: 300px">
			<div class="row">
				<div class="col-md-12">
					
				</div>
			</div>
		</div>
	<?php		
		}
	 ?>


	<!-- CENTER-PAGE -->

	<!-- FOOTER -->
	<?php include_once("footer.php"); ?>
	<!-- FOOTER -->


	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function()
		{
			$('#btnhideDelete').click(function(){
				$('#delete_hide').hide();
			});
			$('#btnhideUpdate').click(function(){
				$('#update_hide').hide();
			});
			$('#btnhideUpdated').click(function()
			{
				$('#alert_updated').hide();
			});
		});
	</script>
</body>
</html>