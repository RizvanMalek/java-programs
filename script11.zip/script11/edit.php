<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
	</style>
</head>
<body>

	<?php include_once("connection.php"); ?>

	<!-- PHP-CODE -->
	<?php 
		if(isset($_POST['btninsert']))
		{
			$code = $_POST['txtcode'];
			$name = $_POST['txtname'];
			$author = $_POST['txtauthor'];
			$price = $_POST['txtprice'];
			$isbn = $_POST['txtisbnno'];
			$insert_query = "INSERT INTO tbl_book VALUES('','$code','$name','$author','$price','$isbn')";
			$insert_result = mysqli_query($conn,$insert_query);
			if($insert_result)
			{
				$alert = 1;	
			}			
		}
	 ?>
	 <?php 
	 	if(isset($_GET['del']))
	 	{
	 		$get_id = $_GET['del'];
	 		$delete_query = "DELETE FROM tbl_book WHERE id='$get_id'";
	 		$delete_result = mysqli_query($conn,$delete_query);
	 		if($delete_result)
	 		{
	 			$alert_delete = 1;
	 		}
	 	}
	  ?>
	<!-- HEADER -->
	<?php include_once("header.php"); ?>
	<!-- HEADER -->

	  <?php  
	  	if(isset($_GET['update']))
	  	{
	  		$get_id = $_GET['update'];
	  		$select_query2 = "SELECT * FROM tbl_book WHERE id='$get_id'";
	  		$select_result2 = mysqli_query($conn,$select_query2);	
		?>

		<?php 
			if(isset($_POST['btnupdate']))
			{
				$get_id = $_GET['update'];
				$code=$_POST['txtcode'];
				$name=$_POST['txtname'];
				$author=$_POST['txtauthor'];
				$price=$_POST['txtprice'];
				$isbn=$_POST['txtisbnno'];
				$update_query = "UPDATE tbl_book SET code='$code',name='$name',author='$author',price='$price',isbn='$isbn' WHERE id='$get_id'";
				$update_result=mysqli_query($conn,$update_query);
				if($update_result)
				{
					$alert_update = 1;
				}	
			}

		 ?>

	<!-- PHP-CODE -->



	<!-- CENTER-PAGE -->
	<div class="container">
		 <div class="row">
		 	<div class="col-md-12">
		 		<?php 
		 			if(isset($alert_update))
		 			{
		 		 ?>
					<div class="alert alert-info" id="alert_updated" style="margin-top: 30px">
						<strong>DATA IS SUCCESSFULLY UPDATED</strong><strong id="btnhideUpdated" style="float: right;cursor: pointer">X</strong>
					</div>		 		
				<?php 
					}
				 ?>	
		 		<?php 
		 			if(isset($alert_delete))
		 			{
		 		 ?>
				<div class="alert alert-info" id="delete_hide">
					<strong>DATA IS SUCCESSFULLY DELETED</strong><strong id="btnhideDelete" style="float: right;cursor: pointer">X</strong>
				</div>		 		
				<?php 
					}
				 ?>	

		<?php	  		
	  		$row=mysqli_fetch_array($select_result2);
		?>
			<div class="container" id="update_hide">
				<div class="row">
					<div class="col-md-6 col-md-offset-3">
						<h3>UPDATE DETAILS <strong id="btnhideUpdate" style="float: right;cursor: pointer">X</strong></h3><hr style="border: 1px solid black">
							<form method="POST">
								<div class="form-group">
									<label>ENTER BOOK CODE</label>
									<input type="text" name="txtcode" value="<?php echo $row[1]; ?>" class="form-control" placeholder="Ente Code...." required>
								</div>

								<div class="form-group">
									<label>ENTER BOOK NAME</label>
									<input type="text" name="txtname" value="<?php echo $row[2]; ?>" class="form-control" placeholder="Ente Name...." required>
								</div>
								<div class="form-group">
									<label>ENTER AUTHOR NAME</label>
									<input type="text" name="txtauthor" value="<?php echo $row[3]; ?>" class="form-control" placeholder="Ente Author Name...." required>
								</div>
								<div class="form-group">
									<label>ENTER BOOK PRICE</label>
									<input type="text" name="txtprice" value="<?php echo $row[4]; ?>" class="form-control" placeholder="Ente Price...." required>
								</div>
								<div class="form-group">
									<label>ENTER BOOK ISBN NO</label>
									<input type="text" name="txtisbnno" value="<?php echo $row[5]; ?>" class="form-control" placeholder="Ente Isbn No...." required>
								</div>

								<div class="form-group">
									<input type="submit" class="btn btn-success btn-block" value="UPDATE BOOK INFORMATION" name="btnupdate">
								</div>
							</form>								
						
					</div>
				</div>
			</div>
		<?php				
			
	  	}
	  ?>

	  	<div class="container" style="margin-top: 20px;margin-bottom: 30px">
	  		<div class="row"> 
	  			 <div class="col-md-12">
	  			 	<h3 class="text text-center">PRODUCT DETAILS</h3><hr style="border: 1px solid black">
				<table class="table table-hover">
					<tr>
						<th>CODE</th>
						<th>NAME</th>
						<th>AUTHOR</th>
						<th>PRICE</th>
						<th>ISBN CODE</th>
						<th>ACTION</th>
					</tr>
					<?php 
						$select_query = "SELECT * FROM tbl_book ORDER BY id ASC";
						$select_result = mysqli_query($conn,$select_query);
						while($row=mysqli_fetch_array($select_result))
						{
					?>
						<tr>
							<td><?php echo $row[1]; ?></td>
							<td><?php echo $row[2]; ?></td>
							<td><?php echo $row[3]; ?></td>
							<td><?php echo $row[4]; ?></td>
							<td><?php echo $row[5]; ?></td>
							<td>
								<a href="edit.php?del=<?php echo $row[0]; ?>" style="color: black;margin-left: 30px"><span class="glyphicon glyphicon-trash"></span></a>
								<a href="edit.php?update=<?php echo $row[0]; ?>" style="color: black;margin-left: 10px"><span class="glyphicon glyphicon-pencil"></span></a>
							</td>
						</tr>
					<?php		
						}						
					 ?>
				</table>		 		


	  			 </div>
	  		</div>
	  	</div>
		 	</div>
		 </div>
	</div>
	<?php 

	?>
	<!-- CENTER-PAGE -->

	<!-- FOOTER -->
	<?php include_once ("footer.php"); ?>
	<!-- FOOTER -->



	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function()
		{
			$('#btnhideDelete').click(function(){
				$('#delete_hide').hide();
			});
			$('#btnhideUpdate').click(function(){
				$('#update_hide').hide();
			});
			$('#btnhideUpdated').click(function()
			{
				$('#alert_updated').hide();
			});
		});
	</script>
</body>
</html>