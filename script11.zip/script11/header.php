<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		.a-style
		{
			color: black;
		}
		.col-md-2:hover
		{
			background-color: #aaaaab;
			transition: 0.8s;
		}

	</style>
</head>
<body>
	<!-- HEADER -->
	<div class="container-fluid">
		<div class="row" style="background-color: #EEEEEE" align="center">
			<div class="col-md-6">
				<h3><a href="index.php" style="color: black;text-decoration: none">ONLINE BOOK STORE</a><button id="hide" style="float: right;border: 0px"><span class="glyphicon glyphicon-list"></span></button></h3>
			</div>
			<div id="hidetab">
			<div class="col-md-2">
				<h3><a href="insert.php" class="a-style" style="text-decoration: none">INSERT</a></h3>
			</div>
			<div class="col-md-2">
				<h3><a href="edit.php" class="a-style" style="text-decoration: none">EDIT</a></h3>
			</div>
			<div class="col-md-2">
				<h3><a href="search.php" class="a-style" style="text-decoration: none">SEARCH</a></h3>
			</div>
			</div>
		</div>
	</div>	
	<!-- HEADER -->

	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function()
		{
			var width = $(window).width();
			$('#hide').hide();
			if(width>=1 && width<=600)
			{
				$('#hide').show();
				$('#hidetab').hide();
				$('#hide').click(function()
				{
					$('#hidetab').slideToggle();
				})
			}
		})
	</script>
</body>
</html>