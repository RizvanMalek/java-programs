<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
	</style>
</head>
<body>

	<?php include_once("connection.php"); ?>

	<!-- PHP-CODE -->
	<?php 
		if(isset($_POST['btninsert']))
		{
			$code = $_POST['txtcode'];
			$name = $_POST['txtname'];
			$author = $_POST['txtauthor'];
			$price = $_POST['txtprice'];
			$isbn = $_POST['txtisbnno'];
			$insert_query = "INSERT INTO tbl_book VALUES('','$code','$name','$author','$price','$isbn')";
			$insert_result = mysqli_query($conn,$insert_query);
			if($insert_result)
			{
				$alert = 1;	
			}			

		}

	 ?>
	<!-- PHP-CODE -->


	<!-- HEADER -->
	<?php include_once("header.php"); ?>
	<!-- HEADER -->

	<!-- CENTER-PAGE -->
		<div class="container" style="background-color: #EEEEEE;margin-top: 10px;margin-bottom: 10px">
			<div class="row">
				<div class="col-md-12">
					<h3 class="text text-center">INSERT BOOK DETAILS</h3><hr style="border: 1px solid white">
					<div class="row">
						<div class="col-md-6 col-md-offset-3" style="background-color: white">
							<h3>BOOK DETAILS</h3><hr style="border: 1px solid black">
							<?php 
								if(isset($alert))
								{																
							 ?>
							<div class="alert alert-success" id="alert_box">
								<strong>DATA IS SUCCESSFULLY INSERTED</strong><strong id="h" style="float: right;cursor: pointer">X</strong>
							</div>
							<?php 
								}
							 ?>							
							<form method="POST">
								<div class="form-group">
									<label>ENTER BOOK CODE</label>
									<input type="text" name="txtcode" class="form-control" placeholder="Ente Code...." required>
								</div>

								<div class="form-group">
									<label>ENTER BOOK NAME</label>
									<input type="text" name="txtname" class="form-control" placeholder="Ente Name...." required>
								</div>
								<div class="form-group">
									<label>ENTER AUTHOR NAME</label>
									<input type="text" name="txtauthor" class="form-control" placeholder="Ente Author Name...." required>
								</div>
								<div class="form-group">
									<label>ENTER BOOK PRICE</label>
									<input type="text" name="txtprice" class="form-control" placeholder="Ente Price...." required>
								</div>
								<div class="form-group">
									<label>ENTER BOOK ISBN NO</label>
									<input type="text" name="txtisbnno" class="form-control" placeholder="Ente Isbn No...." required>
								</div>

								<div class="form-group">
									<input type="submit" class="btn btn-primary btn-block" value="SUBMIT BOOK INFORMATION" name="btninsert">
								</div>

							</form>								
						</div>
					</div>
				</div>
			</div>
		</div>

	<!-- CENTER-PAGE -->

	<!-- FOOTER -->
	<?php include_once ("footer.php"); ?>
	<!-- FOOTER -->



	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function()
		{
			$('#h').click(function()
			{
				$('#alert_box').hide();
			});
		});
	</script>
</body>
</html>