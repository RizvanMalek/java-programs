<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
</head>
<body>

	<!-- FOOTER -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12" style="background-color: black">
				<h3 style="color: white">ABOUT THIS SITE</h3><hr>
				<div style="color: white">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
				</div>
				<div align="center">
					<h3>THIS WEBSITE IS CREATED BY RIZVAN MALEK | 2019</h3>
				</div>
			</div>
		</div>

	</div>

	<!-- FOOTER -->
	
	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>