<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		#t:hover
		{
			box-shadow: 5px 5px 5px 5px;
			transition: 0.5s; 
		}
	</style>	
</head>
<body>

	<?php include("connection.php"); ?>
	<!-- HEADER -->
	<?php include_once("header.php"); ?>	
	<!-- HEADER -->

	<!-- PHP-CODE -->
	<?php 
		if(isset($_POST['btninsert']))
		{
			$sno = $_POST['txtno'];
			$enid = $_POST['txteid'];
			$sname = $_POST['txtname'];
			$gender = $_POST['rdogender'];
			$sage = $_POST['txtage'];
			$contact = $_POST['txtcno'];
			$insert_query = "INSERT INTO tbl_student VALUES('','$sno','$enid','$sname','gender','$sage','$contact')";
			$insert_result = mysqli_query($conn,$insert_query);
			if($insert_result)
			{
				$show_alert=1;
			}			
		}
	 ?>
	<!-- PHP-CODE -->

	<div class="container" style="background-color: #abc5d0;margin-top: 10px;margin-bottom: 20px">
		<div class="row">
			<div class="col-md-6 col-md-offset-3" id="t" style="background-color: white;margin-top: 10px;margin-bottom: 20px">
				<h3>INSERT STUDENT DETAILS</h3>	<hr style="border: 1px solid black">
				<?php 
					if(isset($show_alert))
					{
				?>
					<div id="hidealert" class="alert alert-success">
						<strong>DATA IS SUCCESSFULLY INSERTED <strong id="btnhide" style="float: right;cursor: pointer">X</strong> </strong>
					</div>				

				<?php		
					}
				 ?>				
				<form method="POST">
				<div class="form-group">
					<label>ENTER STUDENT NO</label>
					<input type="text" name="txtno" class="form-control" placeholder="Enter No...." required>
				</div>
				<div class="form-group">
					<label>ENTER ENROLLMENT ID</label>
					<input type="text" name="txteid" class="form-control" placeholder="Enter Enrollment Id...." required>
				</div>

				<div class="form-group">
					<label>ENTER STUDENT NAME</label>
					<input type="text" name="txtname" class="form-control" placeholder="Enter Name...." required>
				</div>

				<div class="form-group">
					<label>SELECT GENDER</label><br>
					<label><input type="radio" name="rdogender" value="MALE"> Male</label>
					<label><input type="radio" name="rdogender" value="FEMALE"> Female</label>

				</div>

				<div class="form-group">
					<label>ENTER STUDENT AGE</label>
					<input type="text" name="txtage" class="form-control" placeholder="Enter Age...." required>
				</div>

				<div class="form-group">
					<label>ENTER STUDENT CONTACT NO</label>
					<input type="text" name="txtcno" class="form-control" placeholder="Enter Contact Number...." required>
				</div>

				<div class="form-group">
					<input type="submit" class="btn btn-primary" value="SUBMIT STUDENT DETAILS" name="btninsert">
				</div>
				</form>								
			</div>
		</div>

	</div>


	<!-- FOOTER -->
	<?php include_once("footer.php"); ?>	
	<!-- FOOTER -->

	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function()
		{
			$('#btnhide').click(function()
			{
				$('#hidealert').hide();
			});
		});	
	</script>
</body>
</html>