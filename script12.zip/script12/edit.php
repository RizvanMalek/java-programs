<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		#t:hover
		{
			box-shadow: 5px 5px 5px 5px;
			transition: 0.5s; 
		}
		#colose:hover
		{
			color: grey;
		}
	</style>	
</head>
<body>

	<?php include("connection.php"); ?>
	<!-- HEADER -->
	<?php include_once("header.php"); ?>	
	<!-- HEADER -->

	<!-- DELETE-ALERT-BOX -->
	<?php 
		if(isset($_GET['del']))
		{
			$get_id = $_GET['del'];
			$delete_query = "DELETE FROM tbl_student WHERE id='$get_id'";
			$delete_result = mysqli_query($conn,$delete_query);	
			if($delete_result)
			{
	?>
	<div class="container" id="hide_delete" style="margin-top: 30px">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">		
				<div class="alert alert-success">
					<strong>DATA HAS BEEN SUCCESSFULLY DELETED <strong style="float: right;cursor: pointer" id="btndeletehide">X</strong> </strong>
				</div>
			</div>
		</div>
	</div>

	<?php
			}			
		}
	?>
	<!-- DELETE-ALERT-BOX -->

	<!-- UPDATE-ALERT-BOX -->
		<?php 
			if(isset($_POST['btnupdate']))
			{
				$get_id = $_GET['update'];
				$sno = $_POST['txtno'];
				$enid = $_POST['txteid'];
				$sname = $_POST['txtname'];

				$gender_temp = "SELECT * FROM tbl_student WHERE id='$get_id'";
				$gender_result = mysqli_query($conn,$gender_temp);
				$database_gender=mysqli_fetch_array($gender_result);				
				$temp = $database_gender[4];
				$gender = $_POST['rdogender'];
				$sage = $_POST['txtage'];
				$contact = $_POST['txtcno'];
				if(isset($gender))
				{
					$update_query = "UPDATE tbl_student SET sno='$sno',eno='$enid',name='$sname',gender='$gender',age='$sage',contactno='$contact' WHERE id='$get_id'";
				}
				else
				{
					$update_query = "UPDATE tbl_student SET sno='$sno',eno='$enid',name='$sname',gender='$temp',age='$sage',contactno='$contact' WHERE id='$get_id'";
				}
				$update_result = mysqli_query($conn,$update_query);
				if($update_result)
				{
					$update_alert=1;
				}				
			}
		 ?>
	
	<?php 
		if(isset($update_alert))
		{
	 ?>
	<div class="container" id="hide_delete" style="margin-top: 30px">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">		
				<div class="alert alert-success">
					<strong>DATA HAS BEEN SUCCESSFULLY UPDATED <strong style="float: right;cursor: pointer" id="btndeletehide">X</strong> </strong>
				</div>
			</div>
		</div>
	</div>

	<?php 
		}
	 ?>


	<!-- UPDATE-ALERT-BOX -->



	<?php 
		if(isset($_GET['update']))
		{
			$get_id = $_GET['update'];
			$select_query2 = "SELECT * FROM tbl_student WHERE id='$get_id'";
			$select_result2 = mysqli_query($conn,$select_query2);
			$row = mysqli_fetch_array($select_result2);			
	?>
	<div class="container" id="t" style="margin-top: 20px;margin-bottom: 20px">
		<div class="row">
			<div class="col-md-12">
				<h2>UPDATE STUDENT DETAILS OR EDIT <strong id="colose" style="float: right;cursor: pointer">X</strong> </h2>				 
				<form method="POST">
				<div class="form-group">
					<label>ENTER STUDENT NO</label>
					<input type="text" name="txtno" value="<?php echo $row[1]; ?>" class="form-control" placeholder="Enter No...." required>
				</div>
				<div class="form-group">
					<label>ENTER ENROLLMENT ID</label>
					<input type="text" name="txteid" value="<?php echo $row[2]; ?>" class="form-control" placeholder="Enter Enrollment Id...." required>
				</div>

				<div class="form-group">
					<label>ENTER STUDENT NAME</label>
					<input type="text" name="txtname" value="<?php echo $row[3]; ?>" class="form-control" placeholder="Enter Name...." required>
				</div>

				<div class="form-group">
					<label>SELECT GENDER</label><br>
					<label><input type="radio" name="rdogender" value="MALE"> Male</label>
					<label><input type="radio" name="rdogender" value="FEMALE"> Female</label>

				</div>

				<div class="form-group">
					<label>ENTER STUDENT AGE</label>
					<input type="text" name="txtage" value="<?php echo $row[5]; ?>" class="form-control" placeholder="Enter Age...." required>
				</div>

				<div class="form-group">
					<label>ENTER STUDENT CONTACT NO</label>
					<input type="text" name="txtcno" value="<?php echo $row[6]; ?>" class="form-control" placeholder="Enter Contact Number...." required>
				</div>

				<div class="form-group">
					<input type="submit" class="btn btn-info" value="UPDATE STUDENT DETAILS" name="btnupdate">
				</div>
				</form>								


			</div>
		</div>
	</div>
	<?php		

		}
	 ?>






	<div class="container" style="background-color: #c4c8ce;margin-top: 30px;margin-bottom: 30px">
	<h3 class="text text-center">STUDENT DETAILS</h3>		
	<table class="table table-hover" style="margin-top: 10px">
		<tr>
			<th>STUDENT NO</th>
			<th>ENROLL ID</th>
			<th>STUDENT NAME</th>
			<th>GENDER</th>
			<th>STUDENT AGE</th>
			<th>CONTACT NO</th>
			<th>ACTION</th>
		</tr>
	
	<?php 
		$select_query = "SELECT * FROM tbl_student ORDER BY id ASC";
		$select_result = mysqli_query($conn,$select_query);		
		while($row = mysqli_fetch_array($select_result))
		{
	?>
		<tr>
			<td><?php echo $row[1]; ?></td>
			<td><?php echo $row[2]; ?></td>
			<td><?php echo $row[3]; ?></td>
			<td><?php echo $row[4]; ?></td>
			<td><?php echo $row[5]; ?></td>
			<td><?php echo $row[6]; ?></td>
			<td>
				<a href="edit.php?del=<?php echo $row[0]; ?>"><span class="glyphicon glyphicon-trash" style="margin-left: 10px"></span></a>
				<a href="edit.php?update=<?php echo $row[0]; ?>"><span class="glyphicon glyphicon-pencil" style="margin-left: 10px"></span></a>
			</td>
		</tr>
	<?php
		}		
	 ?>
	 </table>
	 </div>

	<!-- FOOTER -->
	<?php include_once("footer.php"); ?>	
	<!-- FOOTER -->

	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function()
		{
			$('#btndeletehide').click(function()
			{
				$('#hide_delete').hide();
			});
			$('#colose').click(function()
			{
				$('#t').hide();
			})
		});	
	</script>
</body>
</html>