<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		#t:hover
		{
			box-shadow: 5px 5px 5px 5px;
			transition: 0.5s; 
		}
		#colose:hover
		{
			color: grey;
		}
	</style>	
</head>
<body>

	<?php include("connection.php"); ?>
	<!-- HEADER -->
	<?php include_once("header.php"); ?>	
	<!-- HEADER -->

	<div class="container" style="margin-top: 30px">
		<div class="row">
			<div class="col-md-8">
				<form method="POST">
				 <div class="form-group">
				 	<input type="text" class="form-control" name="txtsearch" placeholder="Search Student Name......">
				 </div>
			</div>
			<div class="col-md-4">
				<div class="form-group">
					<input type="submit" class="btn btn-primary" value="SEARCH DETAILS" name="btnsearch">
				</div>
			</div>
			</form>
		</div>
	</div>

	<!-- PHP-CODE -->
	<?php 
		if(isset($_POST['btnsearch']))
		{
			$name = mysqli_escape_string($conn,$_POST['txtsearch']);
			$select_query = "SELECT * FROM tbl_student WHERE name='$name'";
			$select_result = mysqli_query($conn,$select_query);
			$row=mysqli_fetch_array($select_result);			
		}


	 ?>
	<!-- PHP-CODE -->

	<?php 
		if(isset($row))
		{
	 ?>
	<div class="container" style="background-color: #c4c8ce;margin-top: 30px;margin-bottom: 30px">
	<h3 class="text text-center">SEARCH RESULT.....</h3>		
	<table class="table table-hover" style="margin-top: 10px">
		<tr>
			<th>STUDENT NO</th>
			<th>ENROLL ID</th>
			<th>STUDENT NAME</th>
			<th>GENDER</th>
			<th>STUDENT AGE</th>
			<th>CONTACT NO</th>
		</tr>
	
	<?php 
		$select_query = "SELECT * FROM tbl_student ORDER BY id ASC";
		$select_result = mysqli_query($conn,$select_query);		
		while($row = mysqli_fetch_array($select_result))
		{
	?>
		<tr>
			<td><?php echo $row[1]; ?></td>
			<td><?php echo $row[2]; ?></td>
			<td><?php echo $row[3]; ?></td>
			<td><?php echo $row[4]; ?></td>
			<td><?php echo $row[5]; ?></td>
			<td><?php echo $row[6]; ?></td>
		</tr>
	<?php
		}
		}		
	 ?>
	 </table>
	 </div>

	<!-- FOOTER -->
	<?php include_once("footer.php"); ?>	
	<!-- FOOTER -->

	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function()
		{
			$('#btndeletehide').click(function()
			{
				$('#hide_delete').hide();
			});
			$('#colose').click(function()
			{
				$('#t').hide();
			})
		});	
	</script>
</body>
</html>