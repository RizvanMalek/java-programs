	<!DOCTYPE html>
	<html>
	<head>
		<title>HOME</title>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
		<style type="text/css">
			.col-md-2
			{
				border-top: 1px solid grey;
				border-bottom: 4px solid grey;
				text-align: center;
			}
			.col-md-2:hover
			{
				background-color: white;
				border-bottom: 4px solid skyblue;
				transition: 0.5s;

			}
		</style>	
	</head>
	<body>

		<!-- HEADER -->
			<div class="container-fluid">
				<div class="row" style="background-color: grey;color: white">
					 <div class="col-md-12">
					 	<div class="row" >
					 		 <div class="col-md-6">
					 		 	 <h2><a href="index.php" style="color: white;text-decoration: none">STUDENT MANAGEMENT</a><button id="toggle_button" style="border: 0px;color: white;background-color: grey;margin-left: 40px"><span class="glyphicon glyphicon-th-list"></span></button> </h2>
					 		 </div>
					 		 <div id="hidelist">
					 		 <div class="col-md-2">
					 		 	<h2><a href="insert.php" style="color: black;text-decoration: none">INSERT</a></h2>
					 		 </div>
					 		 <div class="col-md-2">
					 		 	<h2><a href="edit.php" style="color: black;text-decoration: none">EDIT</a></h2>
					 		 </div>
					 		 <div class="col-md-2">
					 		 	<h2><a href="search.php" style="color: black;text-decoration: none">SEARCH</a></h2>
					 		 </div>
					 		</div>
					 	</div>
					 </div>
				</div>
			</div>		

		<!-- HEADER -->


		<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
		<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
		<script type="text/javascript">
			$(document).ready(function(){
				$('#toggle_button').hide();	
				var w = $(window).width();
				if( w>= 100 && w<= 600)
				{
					$('#toggle_button').show();
					$('#hidelist').hide();
					$('#toggle_button').click(function(){
						$('#hidelist').toggle();	
					});
				}				
			});
		</script>		
	</body>
	</html>