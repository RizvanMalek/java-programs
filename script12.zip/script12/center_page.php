<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
</head>
<body>

	<!-- CENTER-PAGE -->
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<img src="img/img4.jpg" width="100%" style="margin-top: 10px;height: 450px" class="img img-thumbnail">
				</div>
			</div>
			<div class="row">
				<div class="col-md-12" align="center" style="background-color: grey;color: white;margin-top: 10px">  
					<h3>ABOUT THIS SITE</h3>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div style="font-size: 20px">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum.						
					</div>

				</div>
			</div>
		</div>

	<!-- CENTER-PAGE -->

	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>