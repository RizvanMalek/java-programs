<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
</head>
<body>

	<!-- HEADER -->
		<?php include_once ("header.php"); ?>
	<!-- HEADER -->

	<!-- CENTER-PAGE -->
		<?php include_once("center_page.php"); ?>
	<!-- CENTER-PAGE -->

	<!-- FOOTER -->
		<?php include_once("footer.php"); ?>
	<!-- FOOTER -->


	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>