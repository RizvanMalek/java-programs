<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
</head>
<body>

	<!-- FOOTER -->
		<div class="container-fluid" style="background-color: black;color: white;padding-top: 20px">
			<div class="row">
				<div class="col-md-6">
					<div style="font-size: 20px"> 
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						
					</div>
				</div>
				<div class="col-md-6">
					<h3>LOGIN</h3>
					<div class="form-group">
						<label>ENTER EMAIL</label>
						<input type="text" class="form-control" name="" placeholder="Enter Email....">
					</div>
					<div class="form-group">
						<label>ENTER PASSWORD</label>
						<input type="text" class="form-control" name="" placeholder="Enter Password....">
					</div>
					<div class="form-group">
						<input type="submit" class="btn btn-primary" value="LOGIN" name="">
					</div>
				</div>
			</div>
			<div class="row"><hr>
				<div class="col-md-12" style="text-align: center">
					<h3>THIS WEBSITE IS CREATED BY RIZVAN | 2019</h3>
				</div>
			</div>
		</div>
	<!-- FOOTER -->

	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>